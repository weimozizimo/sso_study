# 外面的这两个sql文件是oauth服务的建表sql和数据sql
# 由于有Authorization Server - 授权服务器 和 Resource Server - 资源服务器 两个项目，我压缩了一下，解压导入即可，不要忘了在yml里面配置数据库~
项目详解博客地址：https://blog.csdn.net/Victor_An/article/details/81510874
希望大家给点赞^ ^
